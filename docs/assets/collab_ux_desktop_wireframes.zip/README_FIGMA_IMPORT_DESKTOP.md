# Desktop Wireframes (SVG) for Figma

## Frame size
All screens are drawn for **Desktop 1440×900** (wireframe-only).  
This aligns with common desktop frame presets used in Figma (often 1440×1024) and a typical 12-column desktop layout approach.

References:
- Material Design responsive layout grid (12-column patterns at desktop breakpoints).
- Figma community discussion about default desktop frame sizes.

## Import into Figma
1) Open Figma → new file
2) Drag & drop either:
   - `collab_wireframes_desktop_all.svg` (all screens stacked)
   - or individual screens from `/screens/`
3) If using the combined file, select a screen group and **Create frame** (optional) to make it behave like a Figma Frame.

## Files
- `collab_wireframes_desktop_all.svg` — all screens
- `/screens/*.svg` — one screen per file
